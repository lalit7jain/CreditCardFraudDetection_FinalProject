## Checking performance of ROSE sampling technique

library(ROSE)

train.rose <- ROSE(Class~.,data = train,seed=1)$data

library(rpart)
tree.rose <- rpart(Class~.,data = train.rose)
pred.tree.rose <- predict(tree.rose, newdata = test)
auc <- roc(test$Class, pred.tree.rose[,2])

pre <- as.numeric(pred.tree.rose[,2] > 0.4)

caret::confusionMatrix(test$Class, factor(pre))


c <- c()
f <- c()
j <- 1


for(i in seq(0, 0.5 , 0.01)){
  set.seed(7)
 
  tree.rose <- rpart(Class~.,data = train.rose)
  pre <- predict(tree.rose, newdata = test)[,2]
  pre <- as.numeric(pre > i)
  auc <- roc(test$Class, pre)
  c[j] <- i
  f[j] <- as.numeric(auc$auc)
  j <- j + 1
}


df <- data.frame(c = c, f = f)
p <- df$c[which.max(df$f)]


maxs <- apply(train_smot[,-31], 2, max) 
mins <- apply(train_smot[,-31], 2, min)
scaled <- as.data.frame(scale(train_smot[,-31], center = mins, scale = maxs - mins))
scaled <- cbind(scaled,Class = as.numeric(train_smot$Class)-1)

## Feature selection
library(leaps)

regsubsets.fwd <- regsubsets(Class ~ ., data = train_smot, nvmax = 31,method = "forward")
summary(regsubsets.fwd)
resfwd <- summary(regsubsets.fwd)

plot(resfwd$cp)
plot(regsubsets.fwd, scale = "Cp", main = "Cp")
plot(regsubsets.fwd, scale = "adjr2", main = "Adjusted R^2")
plot(regsubsets.fwd, scale = "bic", main = "BIC")
plot(resfwd$adjr2)
coef(regsubsets.fwd,20)

n <- names(coef(regsubsets.fwd,20))
formula <- as.formula(paste("Class ~", paste(n[!n %in% c("(Intercept)")], collapse = " + ")))


train_smot$Class <- as.numeric(train_smot$Class)-1
test_smote$Class <- as.numeric(test_smote$Class)-1


library(neuralnet)
n <- names(train_smot)
f <- as.formula(paste("Class ~", paste(n[!n %in% c("Class")], collapse = " + ")))
set.seed(999)
nn <- neuralnet(f,data=train_smot,linear.output = F,hidden = 17, threshold = 0.1)



pr.nn <- neuralnet::compute(nn,test_smote[,-31])

#Roundig the values
pr.nn$net.result 
pr.nn$net.result <- sapply(pr.nn$net.result,round,digits=0)

## COnfusion matrix
library(caret)
library(e1071)

accuracy <- confusionMatrix(pr.nn$net.result, as.numeric(test_smote$Class)-1)
accuracy

############
#Plotting ROC Curves for Random Forest

c <- c()
f <- c()
j <- 1

library(randomForest)
library(ROCR)
for(i in seq(0, 0.5, 0.01)){
  set.seed(7)
  fit <- randomForest(Class~., data = train_smot)
  pre <- predict(fit, test_smote, type = "prob")[,2]
  pre <- as.numeric(pre > i)
  pred <- ROCR::prediction(pre, test_smote$Class)
  perf <- ROCR::performance(pred, measure = "tpr", x.measure = "fpr") 
  plotName <- paste("ROC/", i,".jpeg")
  jpeg(file = plotName)
  ROCR::plot(perf, col=rainbow(10),main = paste("ROC Curve at Threshold ",i,sep = ""))
  dev.off()
  
  auc <- roc(test_smote$Class, pre)
  c[j] <- i
  f[j] <- as.numeric(auc$auc)
  j <- j + 1
}
df <- data.frame(Threshold = c, AUC = f)









###########
library(randomForest)
fit.rf <- randomForest(Class~., data = train_smot)
pre <- predict(fit.rf, test_smote, type = "prob")[,2]
pre <- as.numeric(pre > 0.34)

print(fit.rf)
importance(fit.rf)
plot(fit.rf)
plot( importance(fit.rf), lty=2, pch=16)
lines(importance(fit.rf))
imp = importance(fit.rf)
impvar = rownames(imp)[order(imp[, 1], decreasing=TRUE)]
op = par(mfrow=c(1, 3))
for (i in seq_along(impvar)) {
  partialPlot(fit.rf, raw, impvar[i], xlab=impvar[i],
              main=paste("Partial Dependence on", impvar[i]),
              ylim=c(0, 1))
}

varImpPlot(fit.rf,
           sort = T,
           main="Variable Importance",
           n.var=10)
# Variable Importance Table
var.imp <- data.frame(importance(fit.rf,
                                 type=2))
var.imp$Variables <- row.names(var.imp)
var.imp[order(var.imp$MeanDecreaseGini,decreasing = T),]


### SVM
library(e1071)
model5 <- svm(Class ~.,data = train_smot,type="C-classification")


pred <- predict(model5,test_smote)
system.time(pred <- predict(model5,test_smote))
d <- caret::confusionMatrix(test_smote$Class, factor(pred))

str(smot_Test)


table(dataset$Class)

r1 <- subset(dataset,Class == 1)[1:4,]
r2 <- subset(dataset,Class == 0)[1:70,]
r3 <- rbind(r1,r2)

split <- sample(1:nrow(r3), nrow(r3))
#random train set.
r3 <- r3[split,]
write.csv(r3,"testingcreditcard.csv")


### 
