getThresholdRF <- function(train,test){
  
  c <- c()
  f <- c()
  j <- 1
  
  library(randomForest)
  library(pROC)
  for(i in seq(0, 0.5 , 0.01)){
    set.seed(7)
    fit <- randomForest(Class~., data = train)
    pre <- predict(fit, test, type = "prob")[,2]
    pre <- as.numeric(pre > i)
    auc <- roc(test$Class, pre)
    c[j] <- i
    f[j] <- as.numeric(auc$auc)
    j <- j + 1
  }
  
  
  df <- data.frame(c = c, f = f)
  p <- df$c[which.max(df$f)]
  return(p)
}

getThresholdLogistic <- function(train,test){
  
  c <- c()
  f <- c()
  j <- 1
  
 
  library(pROC)
  for(i in seq(0, 0.5 , 0.01)){
    set.seed(49)
    model2 <- glm(Class~.,data = train,family = binomial(link = "logit"))
    results <- predict(model2,test[,-c(31)],type = 'response')
    pre <- as.numeric(results > i)
    auc <- roc(test$Class, pre)
    c[j] <- i
    f[j] <- as.numeric(auc$auc)
    j <- j + 1
  }
  
  
  df <- data.frame(c = c, f = f)
  p <- df$c[which.max(df$f)]
  return(p)
}

getThresholdNN <- function(train,test){
  
  c <- c()
  f <- c()
  j <- 1
  
  library(neuralnet)
  n <- names(train)
  fo <- as.formula(paste("Class ~", paste(n[!n %in% c("Class")], collapse = " + ")))
  
  
  library(pROC)
  for(i in seq(0, 0.5 , 0.01)){
    set.seed(999)
    start.time <- Sys.time()
    print(start.time)
    nn <- neuralnet(fo,data=train,linear.output = F,hidden = 17, threshold = 0.1)
    end.time <- Sys.time()
    time.taken <- end.time - start.time
    print(time.taken)
    pr.nn <- neuralnet::compute(nn,test[,-31])
    pre <- as.numeric(pr.nn$net.result  > i)
    auc <- roc(test$Class, pre)
    c[j] <- i
    f[j] <- as.numeric(auc$auc)
    j <- j + 1
  }
  
  
  df <- data.frame(c = c, f = f)
  p <- df$c[which.max(df$f)]
  return(p)
}