
## Reading the csv file

dataset <- read.csv("creditcard.csv",stringsAsFactors = F)

#After we read our data, we take a look into the probablities of our target variable. We already know, from the dataset description, also it is common sense, that such datasets are going to be highly skewed.
prop.table(table(dataset$Class))

set.seed(7)
train <- dataset[1:213093,]
test <- dataset[213094:nrow(dataset),]

prop.table(table(train$Class))
prop.table(table(test$Class))

train$Class <- as.factor(train$Class)
test$Class <- as.factor(test$Class)

## Using SMOTE to handle imbalanced dataset

#set seed for reproducibility
set.seed(7)
#our SMOTed dataset and model using DMwR package
require(DMwR)
train_smote <- SMOTE(Class~., data = train, perc.over = 200, k = 5, perc.under = 200)
set.seed(6)
#putting randomness.
split <- sample(1:nrow(train_smote), nrow(train_smote))
#random train set.
train_smot <- train_smote[split,]


## doing it for testing dataset 
set.seed(7)
#our SMOTed dataset and model using DMwR package
require(DMwR)
test_smote <- SMOTE(Class~., data = test, perc.over = 200, k = 5, perc.under = 200)
set.seed(6)
#putting randomness.
split <- sample(1:nrow(test_smote), nrow(test_smote))
#random train set.
test_smote <- test_smote[split,]


prop.table(table(test_smote$Class))
prop.table(table(train_smot$Class))

##### RANDOM FOREST
set.seed(47)
source("ThresholdCalibration.R")
threshold <- getThresholdRF(train_smot,test_smote)



fit <- randomForest(formula, data = train_smot)
pre <- predict(fit, test_smote, type = "prob")[,2]
pre <- as.numeric(pre > threshold)

#test_smote$pred <- pre
caret::confusionMatrix(test_smote$Class, factor(pre))


pre <- predict(fit, test, type = "prob")[,2]
pre <- as.numeric(pre > threshold)

caret::confusionMatrix(test$Class, factor(pre))

library(ROCR)

pred <- prediction(pre, test_smote$Class)
perf <- performance(pred, measure = "tpr", x.measure = "fpr") 
plot(perf, col=rainbow(10))


##### Logistic Regression

set.seed(7)
test_smote <- SMOTE(Class~., data = test, perc.over = 200, k = 5, perc.under = 200)
set.seed(6)
#putting randomness.
split <- sample(1:nrow(test_smote), nrow(test_smote))
#random train set.
test_smote <- test_smote[split,]


set.seed(49)
source("ThresholdCalibration.R")
threshold <- getThresholdLogistic(train_smot,test_smote)


model2 <- glm(Class~.,data = train_smot,family = binomial(link = "logit"))
results <- predict(model2,test_smote[,-c(31)],type = 'response')
pre <- as.numeric(results > threshold)

caret::confusionMatrix(test_smote$Class, factor(pre))



##### Logistic Regression

set.seed(7)
test_smote <- SMOTE(Class~., data = test, perc.over = 200, k = 5, perc.under = 200)
set.seed(6)
#putting randomness.
split <- sample(1:nrow(test_smote), nrow(test_smote))
#random train set.
test_smote <- test_smote[split,]


set.seed(51)
source("ThresholdCalibration.R")
threshold <- getThresholdLogistic(train_smot,test_smote)


model3 <- glm(Class~.,data = train_smot,family = binomial(link = "logit"))
results <- predict(model2,test_smote[,-c(31)],type = 'response')
pre <- as.numeric(results > threshold)

caret::confusionMatrix(test_smote$Class, factor(pre))


##### Neural Network Classification

set.seed(7)
test_smote <- SMOTE(Class~., data = test, perc.over = 200, k = 5, perc.under = 200)
set.seed(6)
#putting randomness.
split <- sample(1:nrow(test_smote), nrow(test_smote))
#random train set.
test_smote <- test_smote[split,]


set.seed(561)
source("ThresholdCalibration.R")
threshold <- getThresholdNN(train_smot,test_smote)

library(neuralnet)
model4 <- neuralnet(Class~.,data = train_smot, hidden=17,linear.output=FALSE)
pr.nn <- neuralnet::compute(nn,test_smote[,-31])

pre <- as.numeric(pr.nn$net.result > threshold)

caret::confusionMatrix(test_smote$Class, factor(pre))

pr.nn <- neuralnet::compute(nn,test[,-31])
pre <- as.numeric(pr.nn$net.result > threshold)
caret::confusionMatrix(test$Class, factor(pre))

##############

### SVM
library(e1071)
model5 <- svm(Class ~.,data = train_smot,type="C-classification")


pred <- predict(model5,test_smote)
system.time(pred <- predict(model5,test_smote))
caret::confusionMatrix(test_smote$Class, factor(pred))

## Tuning with gird search
n <- names(train_smot)
formula <- as.formula(paste("Class ~", paste(n[!n %in% c("Class")], collapse = " + ")))

svm_tune <- tune(svm, train.x=formula,data = train_smot, kernel="radial", ranges=list(cost=10^(-1:2), gamma=c(.5,1,2)))

svm_model_after_tune <- svm(Class ~ ., data=train_smot, kernel="radial", cost=10, gamma=0.5)
summary(svm_model_after_tune)
system.time(pred <- predict(svm_model_after_tune,test_smote))
caret::confusionMatrix(test_smote$Class, factor(pred))

system.time(pred <- predict(svm_model_after_tune,test))
caret::confusionMatrix(test$Class, factor(pred))



tuneResult <- tune(svm, Class ~ .,  data = train_smot,
                   ranges = list(epsilon = seq(0,1,0.1), cost = 2^(2:9))
)
system.time(pred <- predict(tuneResult$best.model,test_smote))
caret::confusionMatrix(test_smote$Class, factor(pred))


#############

library(ROCR)

pred <- prediction(pre, test_smote$Class)
perf <- performance(pred, measure = "tpr", x.measure = "fpr") 
plot(perf, col=rainbow(10))


### Function for checking the distribution with threshold
plot_pred_type_distribution <- function(df, threshold) {
  v <- rep(NA, nrow(df))
  v <- ifelse(df$pred >= threshold & df$Class == 1, "TP", v)
  v <- ifelse(df$pred >= threshold & df$Class == 0, "FP", v)
  v <- ifelse(df$pred < threshold & df$Class == 1, "FN", v)
  v <- ifelse(df$pred < threshold & df$Class == 0, "TN", v)
  
  df$pred_type <- v
  
  ggplot(data=df, aes(x=Class, y=pred)) + 
    geom_violin(fill=rgb(1,1,1,alpha=0.6), color=NA) + 
    geom_jitter(aes(color=pred_type), alpha=0.6) +
    geom_hline(yintercept=threshold, color="red", alpha=0.6) +
    scale_color_discrete(name = "type") +
    labs(title=sprintf("Threshold at %.2f", threshold))
}

library(ggplot2)
test_pred <- test_smote
test_pred$pred <- pre
plot_pred_type_distribution(test_pred, threshold)


